This application shows the history and transaction of the customers.Here the customers are dummy.
