# Basic-Banking-Application
It shows the transaction and history of different customers.
